import sqlite3
from datetime import datetime
from typing import List, Dict, Optional
import json

class DatabaseManager:
    def __init__(self, db_path: str = "sharpsharks.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """Initialize database schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Props table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS props (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                league TEXT NOT NULL,
                player TEXT NOT NULL,
                prop_type TEXT NOT NULL,
                line REAL NOT NULL,
                odds INTEGER NOT NULL,
                projection REAL,
                edge_pct REAL,
                bookmaker TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(league, player, prop_type, line, bookmaker)
            )
        """)
        
        # Picks table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS picks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                league TEXT NOT NULL,
                player TEXT NOT NULL,
                prop TEXT NOT NULL,
                line REAL NOT NULL,
                pick TEXT NOT NULL,
                confidence REAL,
                reasoning TEXT,
                edge_pct REAL,
                components JSON,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                hit_status TEXT
            )
        """)
        
        # Beats table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS beats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                league TEXT NOT NULL,
                player TEXT NOT NULL,
                text TEXT NOT NULL,
                author TEXT NOT NULL,
                sentiment REAL,
                impact REAL,
                created_at DATETIME,
                likes INTEGER DEFAULT 0
            )
        """)
        
        # Users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                username TEXT UNIQUE NOT NULL,
                hashed_password TEXT NOT NULL,
                tier TEXT DEFAULT 'free',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # User alerts table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                league TEXT NOT NULL,
                player TEXT,
                prop_type TEXT,
                min_edge_pct REAL DEFAULT 5.0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        
        # Wallet/transaction table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                prop_id INTEGER,
                pick_id INTEGER,
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        
        conn.commit()
        conn.close()
    
    def insert_prop(self, prop: Dict) -> int:
        """Insert or ignore duplicate prop"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO props 
                (league, player, prop_type, line, odds, projection, edge_pct, bookmaker)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                prop["league"],
                prop["player"],
                prop["prop_type"],
                prop["line"],
                prop["odds"],
                prop.get("projection"),
                prop.get("edge_pct"),
                prop.get("bookmaker")
            ))
            conn.commit()
            return cursor.lastrowid
        except sqlite3.IntegrityError:
            return None
        finally:
            conn.close()
    
    def get_props_by_league(self, league: str, limit: int = 100) -> List[Dict]:
        """Get props for league"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM props 
            WHERE league = ? 
            ORDER BY edge_pct DESC 
            LIMIT ?
        """, (league, limit))
        
        rows = cursor.fetchall()
        conn.close()
        
        return [dict(row) for row in rows]
    
    def insert_pick(self, pick: Dict) -> int:
        """Insert ML pick"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO picks 
            (league, player, prop, line, pick, confidence, reasoning, edge_pct, components)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            pick["league"],
            pick["player"],
            pick["prop"],
            pick["line"],
            pick["pick"],
            pick.get("confidence"),
            pick.get("reasoning"),
            pick.get("edge_pct"),
            json.dumps(pick.get("components", {}))
        ))
        
        conn.commit()
        conn.close()
        return cursor.lastrowid
    
    def insert_beat(self, beat: Dict) -> int:
        """Insert beat writer tweet"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO beats 
            (league, player, text, author, sentiment, impact, created_at, likes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            beat["league"],
            beat["player"],
            beat["text"],
            beat["author"],
            beat.get("sentiment"),
            beat.get("impact"),
            beat.get("created_at"),
            beat.get("likes", 0)
        ))
        
        conn.commit()
        conn.close()
        return cursor.lastrowid
    
    def get_user_alerts(self, user_id: int) -> List[Dict]:
        """Get user's edge alerts"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM alerts WHERE user_id = ?", (user_id,))
        rows = cursor.fetchall()
        conn.close()
        
        return [dict(row) for row in rows]

db_manager = DatabaseManager()
