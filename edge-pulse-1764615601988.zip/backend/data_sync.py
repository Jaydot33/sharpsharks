import asyncio
import json
from datetime import datetime
from typing import List, Dict, Any
from apis import odds_client, twitter_client, picks_client
from database import supabase_db

class DataSyncManager:
    """Manages continuous data synchronization from external APIs"""
    
    def __init__(self):
        self.sync_interval = 60  # 1 minute
        self.running = False
    
    async def start(self):
        """Start continuous data sync"""
        self.running = True
        print("DataSyncManager started")
        
        # Initial sync
        await self.sync_all_leagues()
        
        # Continuous sync loop
        while self.running:
            try:
                await asyncio.sleep(self.sync_interval)
                await self.sync_all_leagues()
            except Exception as e:
                print(f"Sync error: {e}")
    
    async def sync_all_leagues(self):
        """Sync props for all supported leagues"""
        leagues = ["NBA", "NFL", "NCAAB", "CFB"]
        
        for league in leagues:
            try:
                props = await odds_client.get_player_props(league)
                if props:
                    await self.store_props(props, league)
                    print(f"✓ Synced {len(props)} {league} props")
            except Exception as e:
                print(f"Error syncing {league}: {e}")
    
    async def store_props(self, props: List[Dict], league: str):
        """Store synced props in database"""
        try:
            for prop in props:
                # Ensure all required fields
                prop_data = {
                    "league": league,
                    "player": prop.get("player", ""),
                    "prop_type": prop.get("prop_type", ""),
                    "line": float(prop.get("line", 0)),
                    "odds": int(prop.get("odds", -110)),
                    "bookmaker": prop.get("bookmaker", ""),
                    "projection": float(prop.get("projection", prop.get("line", 0))),
                    "edge_pct": self.calculate_edge(
                        float(prop.get("projection", 0)),
                        float(prop.get("line", 0)),
                        int(prop.get("odds", -110))
                    ),
                    "timestamp": datetime.utcnow().isoformat()
                }
                
                await supabase_db.upsert_prop(prop_data)
        except Exception as e:
            print(f"Error storing props: {e}")
    
    def calculate_edge(self, projection: float, line: float, odds: int) -> float:
        """Calculate implied edge percentage"""
        if projection <= 0 or line <= 0:
            return 0.0
        
        # Determine if over/under
        is_over = projection > line
        diff = abs(projection - line)
        
        # Simple odds-to-probability conversion
        # -110 odds = ~52.4% implied probability
        if odds < 0:
            prob = abs(odds) / (abs(odds) + 100)
        else:
            prob = 100 / (odds + 100)
        
        # Edge = (actual probability - implied probability) * 100
        edge = ((diff / line) - prob) * 100
        
        return round(max(0, edge), 2)
    
    def stop(self):
        """Stop data sync"""
        self.running = False
        print("DataSyncManager stopped")


data_sync_manager = DataSyncManager()
