import requests
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import os

logger = logging.getLogger(__name__)

class OddsAPIService:
    """Service to fetch odds data from TheOddsAPI"""
    
    BASE_URL = "https://api.the-odds-api.com/v4"
    API_KEY = os.getenv("ODDS_API_KEY", "b4442eb07c0cdc3007a1b5120144cfd3")
    
    # Sport mappings to TheOddsAPI sport keys
    SPORT_MAPPINGS = {
        "NBA": "basketball_nba",
        "NFL": "americanfootball_nfl",
        "NCAAB": "basketball_ncaab",
        "CFB": "americanfootball_college"
    }
    
    # Player prop markets for each league
    PLAYER_PROP_MARKETS = {
        "NBA": ["player_points", "player_rebounds", "player_assists", "player_threes"],
        "NFL": ["player_pass_yds", "player_rush_yds", "player_pass_td", "player_rush_td", "player_receptions"]
    }
    
    # Team prop markets for college
    TEAM_PROP_MARKETS = {
        "NCAAB": ["spreads", "totals"],
        "CFB": ["spreads", "totals"]
    }
    
    def get_league_props(self, league: str, date: Optional[str] = None) -> List[Dict]:
        """
        Fetch props for a league
        
        Args:
            league: NBA, NFL, NCAAB, or CFB
            date: Optional date in YYYY-MM-DD format (defaults to today)
        
        Returns:
            List of props with edge calculations
        """
        
        if league not in self.SPORT_MAPPINGS:
            return []
        
        if date is None:
            date = datetime.utcnow().strftime("%Y-%m-%d")
        
        try:
            sport_key = self.SPORT_MAPPINGS[league]
            
            if league in ["NBA", "NFL"]:
                return self._fetch_player_props(sport_key, league)
            else:  # NCAAB, CFB
                return self._fetch_team_props(sport_key, league)
        
        except Exception as e:
            logger.error(f"Error fetching props for {league}: {str(e)}")
            return []
    
    def _fetch_player_props(self, sport_key: str, league: str) -> List[Dict]:
        """Fetch player props for NBA/NFL"""
        
        props = []
        markets = self.PLAYER_PROP_MARKETS.get(league, [])
        
        for market in markets:
            try:
                url = f"{self.BASE_URL}/sports/{sport_key}/events"
                params = {
                    "apiKey": self.API_KEY,
                    "markets": market,
                    "oddsFormat": "decimal"
                }
                
                response = requests.get(url, params=params, timeout=10)
                
                if response.status_code != 200:
                    logger.warning(f"TheOddsAPI returned {response.status_code} for {sport_key}/{market}")
                    continue
                
                data = response.json()
                
                for event in data:
                    # Filter for today's games only
                    event_date = datetime.fromisoformat(event["commence_time"].replace("Z", "+00:00"))
                    today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
                    tomorrow = today + timedelta(days=1)
                    
                    if not (today <= event_date < tomorrow):
                        continue
                    
                    # Parse bookmakers
                    for bookmaker in event.get("bookmakers", []):
                        for market_data in bookmaker.get("markets", []):
                            if market_data["key"] != market:
                                continue
                            
                            for outcome in market_data.get("outcomes", []):
                                player_name = outcome.get("description", "Unknown")
                                
                                # Extract prop type from market
                                prop_type = self._parse_prop_type(market)
                                
                                prop = {
                                    "league": league,
                                    "player": player_name,
                                    "team": event.get("home_team", ""),
                                    "opponent": event.get("away_team", ""),
                                    "prop_type": prop_type,
                                    "line": outcome.get("point", None),
                                    "odds": outcome.get("price", 0),
                                    "bookmaker": bookmaker.get("title", "Unknown"),
                                    "timestamp": datetime.utcnow().isoformat(),
                                    "game_time": event.get("commence_time", ""),
                                    "market_key": market
                                }
                                
                                # Calculate projection and edge
                                projection = self._get_projection(player_name, league, prop_type)
                                prop["projection"] = projection
                                prop["edge_pct"] = self._calculate_edge(projection, prop["line"], prop["odds"])
                                
                                props.append(prop)
            
            except Exception as e:
                logger.error(f"Error fetching {market} for {sport_key}: {str(e)}")
                continue
        
        return props
    
    def _fetch_team_props(self, sport_key: str, league: str) -> List[Dict]:
        """Fetch team props for NCAAB/CFB (spreads and totals)"""
        
        props = []
        
        try:
            url = f"{self.BASE_URL}/sports/{sport_key}/events"
            params = {
                "apiKey": self.API_KEY,
                "markets": "spreads,totals",
                "oddsFormat": "decimal"
            }
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code != 200:
                logger.warning(f"TheOddsAPI returned {response.status_code} for {sport_key}")
                return props
            
            data = response.json()
            
            for event in data:
                # Filter for today's games only
                event_date = datetime.fromisoformat(event["commence_time"].replace("Z", "+00:00"))
                today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
                tomorrow = today + timedelta(days=1)
                
                if not (today <= event_date < tomorrow):
                    continue
                
                home_team = event.get("home_team", "")
                away_team = event.get("away_team", "")
                
                # Parse bookmakers
                for bookmaker in event.get("bookmakers", []):
                    for market_data in bookmaker.get("markets", []):
                        market_key = market_data["key"]
                        
                        for outcome in market_data.get("outcomes", []):
                            if market_key == "spreads":
                                team = outcome.get("description", "")
                                line = outcome.get("point", None)
                                prop_type = "Spread"
                            else:  # totals
                                team = f"{home_team} vs {away_team}"
                                line = outcome.get("point", None)
                                prop_type = f"Total {outcome.get('name', 'O/U')}"
                            
                            prop = {
                                "league": league,
                                "player": team,
                                "team": home_team,
                                "opponent": away_team,
                                "prop_type": prop_type,
                                "line": line,
                                "odds": outcome.get("price", 0),
                                "bookmaker": bookmaker.get("title", "Unknown"),
                                "timestamp": datetime.utcnow().isoformat(),
                                "game_time": event.get("commence_time", ""),
                                "market_key": market_key
                            }
                            
                            # Calculate projection and edge
                            projection = self._get_team_projection(team, league, prop_type)
                            prop["projection"] = projection
                            prop["edge_pct"] = self._calculate_edge(projection, line, prop["odds"])
                            
                            props.append(prop)
        
        except Exception as e:
            logger.error(f"Error fetching team props for {sport_key}: {str(e)}")
        
        return props
    
    def _parse_prop_type(self, market: str) -> str:
        """Convert market key to readable prop type"""
        
        mapping = {
            "player_points": "Points",
            "player_rebounds": "Rebounds",
            "player_assists": "Assists",
            "player_threes": "3-Pointers",
            "player_pass_yds": "Pass Yards",
            "player_rush_yds": "Rush Yards",
            "player_pass_td": "Pass TD",
            "player_rush_td": "Rush TD",
            "player_receptions": "Receptions"
        }
        
        return mapping.get(market, market)
    
    def _get_projection(self, player_name: str, league: str, prop_type: str) -> float:
        """
        Get player projection (mock data for now, replace with HOF API)
        """
        
        # Mock projections based on player and prop type
        mock_projections = {
            ("Nikola Jokic", "NBA", "Rebounds"): 11.8,
            ("Nikola Jokic", "NBA", "Points"): 28.5,
            ("Nikola Jokic", "NBA", "Assists"): 9.2,
            ("LeBron James", "NBA", "Points"): 24.3,
            ("LeBron James", "NBA", "Rebounds"): 8.1,
            ("LeBron James", "NBA", "Assists"): 9.7,
            ("Patrick Mahomes", "NFL", "Pass Yards"): 285.0,
            ("Patrick Mahomes", "NFL", "Pass TD"): 2.1,
        }
        
        key = (player_name, league, prop_type)
        return mock_projections.get(key, 0)
    
    def _get_team_projection(self, team: str, league: str, prop_type: str) -> float:
        """Get team projection (mock data for now)"""
        
        # Simple mock team projections
        if "Total" in prop_type:
            return 155.0  # Generic total
        elif "Spread" in prop_type:
            return 2.5  # Generic spread
        return 0
    
    def _calculate_edge(self, projection: float, line: Optional[float], odds: float) -> float:
        """
        Calculate edge percentage
        Edge = ((projected_value - line) / line) * 100 if odds are favorable
        """
        
        if not line or line == 0 or projection == 0:
            return 0
        
        try:
            # Simple edge calculation
            edge = ((projection - line) / line) * 100
            
            # Adjust for odds (rough approximation)
            # Negative odds = favorite, positive = underdog
            if odds < 1.5:
                edge *= 0.5  # Reduce edge for bad odds
            elif odds > 2.0:
                edge *= 1.5  # Increase edge for good odds
            
            return round(edge, 2)
        
        except Exception as e:
            logger.error(f"Error calculating edge: {str(e)}")
            return 0

# Create singleton instance
odds_api_service = OddsAPIService()
