# SharpSharks Backend API

Advanced sports betting analytics engine with real-time odds, beat writer sentiment, and ML-powered picks.

## Quick Start

### Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Create .env file
cp .env.example .env
# Fill in your API keys:
# - ODDS_API_KEY from the-odds-api.com
# - X_BEARER_TOKEN from developer.twitter.com
# - REDIS_URL from Redis Cloud (optional, falls back to in-memory)

# Run server
python main.py
```

Server runs on `http://localhost:5000`

## Environment Variables

| Variable | Required | Example |
|----------|----------|---------|
| `ODDS_API_KEY` | Yes | Get free 500 calls/mo from the-odds-api.com |
| `X_BEARER_TOKEN` | Yes | Generate from developer.twitter.com for beat tweets |
| `REDIS_URL` | No | Redis Cloud URL for 5min prop caching |
| `DISCORD_WEBHOOK` | No | Discord channel for VIP edge alerts |
| `JWT_SECRET` | Yes | Change in production |
| `PORT` | No | Default 5000 |

## API Endpoints

### Authentication
- `POST /auth/register` - Register new user
- `POST /auth/login` - Login and get JWT token

### Props & Edges
- `GET /api/props/{league}` - Get player props (NBA/NFL/NCAAB/CFB)
  - Query: `min_edge=5.0` (minimum edge percentage)
  - Response: 100 top edges sorted by edge%

### Beat Writer Sentiment
- `GET /api/beats/{player}` - Get injury/usage news
  - Query: `league=NBA`
  - Response: Recent tweets with sentiment (-1 to +1)

### ML Smart Picks
- `GET /api/picks/{league}` - Get ML recommendations
  - Response: Picks with confidence, reasoning, component breakdown

### Utilities
- `POST /api/alerts` - Create edge alert (Discord notification)
- `POST /api/parlay-simulation` - Monte Carlo for parlay chains
- `GET /api/cache-status` - Check Redis/cache status

## Data Flows

**Props (1-5s latency)**:
- TheOddsAPI → Cache (5min TTL) → Response

**Beats (real-time)**:
- Twitter/X API → Sentiment analysis → Cache (5min TTL)

**Picks (ML)**:
- HOF projections (40%) + Smart model (30%) + PropFinder (20%) + Beat sentiment (10%)

## Deployment

### Render (Recommended)
```bash
# Push to git
git push origin main

# Connect to Render via render.yaml
# Auto-deploys on push, includes Redis + API service
```

### Vercel (Frontend Only)
```bash
npm run build
vercel deploy
```

## Rate Limiting

- Free tier: 500 calls/month to TheOddsAPI
- Twitter/X API: 450 requests/15min window
- Redis caching reduces API calls significantly

## Database Schema

**Props Table**: league, player, prop_type, line, odds, projection, edge_pct
**Picks Table**: league, player, prop, confidence, reasoning, components
**Beats Table**: league, player, text, author, sentiment, impact
**Users Table**: email, username, tier (free/pro), created_at
**Alerts Table**: user_id, league, player, min_edge_pct

## Support

- Issue: API rate limit exceeded → Upgrade API key tier
- Issue: Redis connection failed → Falls back to in-memory cache automatically
- Issue: Twitter API 401 → Regenerate bearer token at developer.twitter.com

## Next Refinements

1. **Live WebSocket Updates** - Real-time prop/pick streaming
2. **Historical Backtesting** - Test edge strategies over time
3. **Affiliate Integration** - Sportsbook commission tracking
