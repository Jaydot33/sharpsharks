import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Minus, ExternalLink, RefreshCw } from "lucide-react";
import { beatsService, type Beat } from '../services/beats';
import { Badge } from "./ui/badge";
import { Card, CardContent } from "./ui/card";

export default function LiveBeatBuzz() {
  const [selectedLeague, setSelectedLeague] = useState('NBA');
  const [beats, setBeats] = useState<Beat[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const leagues = ['NBA', 'NFL', 'NCAAB', 'CFB'];

  useEffect(() => {
    fetchBeats();
    // Auto-refresh every 5 minutes
    const interval = setInterval(fetchBeats, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [selectedLeague]);

  const fetchBeats = async () => {
    setLoading(true);
    try {
      const data = await beatsService.getLeagueBuzz(selectedLeague, 24);
      setBeats(data.buzz);
    } catch (error) {
      console.error('Error loading beats:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchBeats();
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-2xl font-bold text-white">Beat Buzz</h2>
        
        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 rounded-lg bg-gray-800 border border-gray-700 hover:border-teal-500 transition-all duration-200"
          >
            <RefreshCw className={`w-4 h-4 text-teal-400 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
          
          <div className="flex gap-2">
            {leagues.map((league) => (
              <button
                key={league}
                onClick={() => setSelectedLeague(league)}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  selectedLeague === league
                    ? 'bg-teal-500 text-white'
                    : 'bg-gray-800 text-gray-400 hover:text-white border border-gray-700 hover:border-gray-600'
                }`}
              >
                {league}
              </button>
            ))}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#00d4ff] mx-auto"></div>
          <p className="mt-4 text-gray-400">Loading beat buzz...</p>
        </div>
      ) : beats.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-400">No recent tweets found</p>
        </div>
      ) : (
        <div className="space-y-4">
          {beats.map((beat) => {
            const ImpactIcon =
              beat.sentiment.type === "positive"
                ? TrendingUp
                : beat.sentiment.type === "negative"
                ? TrendingDown
                : Minus;

            const impactColor =
              beat.sentiment.type === "positive"
                ? "text-green-400"
                : beat.sentiment.type === "negative"
                ? "text-red-400"
                : "text-gray-400";

            const sentimentWidth = Math.abs(beat.sentiment.score) * 100;
            const sentimentColor =
              beat.sentiment.score > 0 ? "bg-green-500" : "bg-red-500";

            return (
              <Card
                key={beat.id}
                className="bg-gray-800 border-gray-700 hover:border-teal-500 transition-all duration-300"
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-3">
                      <div className="flex items-center gap-3 flex-wrap">
                        <ImpactIcon className={`w-5 h-5 ${impactColor}`} />
                        <div className="flex items-center gap-2">
                          <span className="text-white font-semibold">
                            @{beat.author_username}
                          </span>
                          {beat.verified && (
                            <Badge variant="outline" className="border-blue-500 text-blue-400 text-xs">
                              Verified
                            </Badge>
                          )}
                          {beat.writer_rank && (
                            <Badge variant="outline" className="border-teal-500 text-teal-400 text-xs">
                              Top {beat.writer_rank}
                            </Badge>
                          )}
                        </div>
                        <span className="text-gray-500 text-sm">
                          {formatTimeAgo(beat.created_at)}
                        </span>
                      </div>

                      <p className="text-gray-300 leading-relaxed">
                        {beat.text}
                      </p>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-400">
                            Sentiment Impact
                          </span>
                          <span className={`font-semibold ${impactColor}`}>
                            {beat.impact > 0 ? '+' : ''}{beat.impact.toFixed(1)}%
                          </span>
                        </div>
                        <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${sentimentColor} transition-all duration-500`}
                            style={{ width: `${sentimentWidth}%` }}
                          />
                        </div>
                        
                        <div className="flex gap-4 text-xs text-gray-400">
                          <span>❤️ {beat.likes.toLocaleString()}</span>
                          <span>🔄 {beat.retweets.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <a
                      href={`https://twitter.com/${beat.author_username}/status/${beat.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors duration-200"
                    >
                      <ExternalLink className="w-4 h-4 text-gray-400" />
                    </a>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
