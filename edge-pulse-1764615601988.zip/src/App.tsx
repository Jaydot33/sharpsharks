import { useState } from "react";
import { Flame, Search, Newspaper, Brain, BarChart3, Wallet } from "lucide-react";
import LiveTicker from "./components/LiveTicker";
import { Scanner } from "./components/Scanner";
import LiveBeatBuzz from "./components/LiveBeatBuzz";
import SmartPicks from "./components/SmartPicks";
import Analytics from "./components/Analytics";
import { Button } from "./components/ui/button";
import { Badge } from "./components/ui/badge";

type Tab = "scanner" | "buzz" | "picks" | "analytics";

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("scanner");

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="bg-gray-950 border-b border-gray-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-teal-500 to-cyan-600 p-2 rounded-lg">
                <Flame className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent">
                  SharpSharks
                </h1>
                <p className="text-xs text-gray-400">Advanced Betting Edge Finder</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Badge variant="outline" className="border-teal-500 text-teal-400 hidden sm:flex">
                NBA • NFL • NCAAB • CFB
              </Badge>
              <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:text-white">
                <Wallet className="w-4 h-4 mr-2" />
                Track Wallet
              </Button>
              <Button size="sm" className="bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white">
                Upgrade Pro
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Live Ticker */}
      <LiveTicker />

      {/* Navigation Tabs */}
      <div className="bg-gray-900 border-b border-gray-800 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex gap-2 py-4 overflow-x-auto">
            <Button
              variant={activeTab === "scanner" ? "default" : "ghost"}
              className={
                activeTab === "scanner"
                  ? "bg-teal-600 text-white"
                  : "text-gray-400 hover:text-white hover:bg-gray-800"
              }
              onClick={() => setActiveTab("scanner")}
            >
              <Search className="w-4 h-4 mr-2" />
              Edge Scanner
            </Button>
            <Button
              variant={activeTab === "buzz" ? "default" : "ghost"}
              className={
                activeTab === "buzz"
                  ? "bg-teal-600 text-white"
                  : "text-gray-400 hover:text-white hover:bg-gray-800"
              }
              onClick={() => setActiveTab("buzz")}
            >
              <Newspaper className="w-4 h-4 mr-2" />
              Beat Buzz
            </Button>
            <Button
              variant={activeTab === "picks" ? "default" : "ghost"}
              className={
                activeTab === "picks"
                  ? "bg-teal-600 text-white"
                  : "text-gray-400 hover:text-white hover:bg-gray-800"
              }
              onClick={() => setActiveTab("picks")}
            >
              <Brain className="w-4 h-4 mr-2" />
              Smart Picks
            </Button>
            <Button
              variant={activeTab === "analytics" ? "default" : "ghost"}
              className={
                activeTab === "analytics"
                  ? "bg-teal-600 text-white"
                  : "text-gray-400 hover:text-white hover:bg-gray-800"
              }
              onClick={() => setActiveTab("analytics")}
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Analytics
            </Button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "scanner" && <Scanner />}
        {activeTab === "buzz" && <LiveBeatBuzz />}
        {activeTab === "picks" && <SmartPicks />}
        {activeTab === "analytics" && <Analytics />}
      </main>

      {/* Footer */}
      <footer className="bg-gray-950 border-t border-gray-800 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-gray-400">
              <Flame className="w-5 h-5 text-teal-400" />
              <span>© 2025 SharpSharks - Advanced Betting Analytics</span>
            </div>
            <div className="flex items-center gap-6 text-sm text-gray-400">
              <a href="#" className="hover:text-teal-400 transition-colors">
                Terms
              </a>
              <a href="#" className="hover:text-teal-400 transition-colors">
                Privacy
              </a>
              <a href="#" className="hover:text-teal-400 transition-colors">
                Responsible Gaming
              </a>
              <Badge variant="outline" className="border-green-500 text-green-400">
                21+ Only
              </Badge>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
