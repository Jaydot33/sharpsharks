# Today's Props Configuration

## NBA/NFL: Player Props Only
- **NBA**: Points, Rebounds, Assists, 3-Pointers, PRA combos
- **NFL**: Pass Yards, Pass TDs, Rush Yards, Receptions, Receiving Yards

Only shows props for players in games scheduled TODAY.

## NCAAB/CFB: Team Props Only
- **NCAAB**: Team Spreads, Game Totals (O/U)
- **CFB**: Team Spreads, Game Totals (O/U)

Only shows team-based props for games scheduled TODAY.

## Example Output

### NBA Today (Player Props)
```
LeBron James - LAL vs DEN
  Points O/U 25.5 (-110) | Projection: 27.2 | Edge: 6.7%
  
Nikola Jokic - DEN @ LAL
  Rebounds O/U 11.5 (-115) | Projection: 12.8 | Edge: 11.3%
```

### NCAAB Today (Team Props)
```
Duke vs UNC
  Duke Spread -4.5 (-110) | Projection: -5.2 | Edge: 15.6%
  Total O/U 155.5 (-110) | Projection: 158.3 | Edge: 1.8%
```

## API Response Format

Player props include:
- `player`: Player name
- `team`: Player's team
- `opponent`: Opposing team
- `prop_type`: Points, Rebounds, Pass Yards, etc.

Team props include:
- `player`: Team name (for spreads) or "Team A vs Team B" (for totals)
- `team`: Home team
- `opponent`: Away team
- `prop_type`: "Spread" or "Total O/U"

All props filtered to TODAY's games only via UTC date matching.
