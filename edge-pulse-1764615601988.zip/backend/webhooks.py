import httpx
from typing import Optional
from config import settings
import json

class WebhookManager:
    def __init__(self):
        self.discord_webhook = settings.discord_webhook
    
    async def send_edge_alert(self, prop: dict, user_email: str):
        """Send Discord alert for high edge opportunity"""
        if not self.discord_webhook:
            return
        
        try:
            embed = {
                "title": f"🦈 Sharp Edge Alert: {prop['player']}",
                "description": f"{prop['prop_type'].title()} {prop['line']}",
                "color": 0x00d4ff,
                "fields": [
                    {"name": "Edge", "value": f"{prop['edge_pct']}%", "inline": True},
                    {"name": "League", "value": prop['league'], "inline": True},
                    {"name": "Bookmaker", "value": prop.get('bookmaker', 'N/A'), "inline": True},
                    {"name": "Odds", "value": str(prop['odds']), "inline": True},
                ],
                "footer": {"text": f"User: {user_email}"}
            }
            
            payload = {"embeds": [embed]}
            
            async with httpx.AsyncClient() as client:
                await client.post(self.discord_webhook, json=payload)
        except Exception as e:
            print(f"Discord webhook error: {e}")
    
    async def send_beat_alert(self, beat: dict, player: str):
        """Send Discord alert for beat writer news"""
        if not self.discord_webhook:
            return
        
        try:
            sentiment_emoji = "🟢" if beat['sentiment'] > 0 else "🔴"
            
            embed = {
                "title": f"{sentiment_emoji} Beat Alert: {player}",
                "description": beat['text'][:200],
                "color": 0x00d4ff,
                "fields": [
                    {"name": "Author", "value": beat['author'], "inline": True},
                    {"name": "Sentiment", "value": f"{beat['sentiment']:.2f}", "inline": True},
                    {"name": "Impact", "value": f"±{beat['impact']:.1f}%", "inline": True},
                    {"name": "League", "value": beat['league'], "inline": True},
                ],
                "footer": {"text": beat['created_at']}
            }
            
            payload = {"embeds": [embed]}
            
            async with httpx.AsyncClient() as client:
                await client.post(self.discord_webhook, json=payload)
        except Exception as e:
            print(f"Discord webhook error: {e}")

webhook_manager = WebhookManager()
