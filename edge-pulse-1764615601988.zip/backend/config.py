import os
from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    odds_api_key: str = os.getenv("ODDS_API_KEY", "b4442eb07c0cdc3007a1b5120144cfd3")
    x_bearer_token: str = os.getenv("X_BEARER_TOKEN", "")
    redis_url: str = os.getenv("REDIS_URL", "")
    port: int = int(os.getenv("PORT", 5000))
    backend_url: str = os.getenv("BACKEND_URL", "http://localhost:5000")
    discord_webhook: Optional[str] = os.getenv("DISCORD_WEBHOOK")
    jwt_secret: str = os.getenv("JWT_SECRET", "change-me-in-production")
    environment: str = os.getenv("ENVIRONMENT", "development")
    
    class Config:
        env_file = ".env"

settings = Settings()
