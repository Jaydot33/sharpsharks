const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000';

export interface Beat {
  id: string;
  text: string;
  author_username: string;
  author_name: string;
  verified: boolean;
  created_at: string;
  likes: number;
  retweets: number;
  sentiment: {
    score: number;
    type: 'positive' | 'negative' | 'neutral';
    injury_signals: number;
    positive_signals: number;
    usage_signals: number;
  };
  impact: number;
  league: string;
  player?: string;
  writer_rank?: number;
}

export interface BeatsResponse {
  player?: string;
  league: string;
  beats: Beat[];
  count: number;
  cached: boolean;
}

export interface BuzzResponse {
  league: string;
  buzz: Beat[];
  count: number;
  cached: boolean;
}

export const beatsService = {
  async getPlayerBeats(player: string, league: string = 'NBA', hours: number = 24): Promise<BeatsResponse> {
    try {
      const response = await fetch(
        `${BACKEND_URL}/api/beats/${encodeURIComponent(player)}?league=${league}&hours=${hours}`
      );
      
      if (!response.ok) {
        throw new Error(`Failed to fetch beats: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error fetching player beats:', error);
      // Return mock data as fallback
      return {
        player,
        league,
        beats: getMockBeats(player, league),
        count: 5,
        cached: false
      };
    }
  },

  async getLeagueBuzz(league: string = 'NBA', hours: number = 6): Promise<BuzzResponse> {
    try {
      const response = await fetch(
        `${BACKEND_URL}/api/beats/league/${league}?hours=${hours}`
      );
      
      if (!response.ok) {
        throw new Error(`Failed to fetch buzz: ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error fetching league buzz:', error);
      // Return mock data as fallback
      return {
        league,
        buzz: getMockBuzz(league),
        count: 10,
        cached: false
      };
    }
  }
};

// Mock data for development/fallback
function getMockBeats(player: string, league: string): Beat[] {
  const now = new Date();
  return [
    {
      id: '1',
      text: `${player} listed as probable for tonight's game after full practice yesterday. Coach says he looks great.`,
      author_username: league === 'NBA' ? 'wojespn' : 'AdamSchefter',
      author_name: league === 'NBA' ? 'Adrian Wojnarowski' : 'Adam Schefter',
      verified: true,
      created_at: new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString(),
      likes: 1245,
      retweets: 423,
      sentiment: { score: 0.75, type: 'positive', injury_signals: 0, positive_signals: 3, usage_signals: 1 },
      impact: 8.5,
      league,
      player
    },
    {
      id: '2',
      text: `${player} dealing with minor soreness but expected to play through it tonight.`,
      author_username: league === 'NBA' ? 'ShamsCharania' : 'RapSheet',
      author_name: league === 'NBA' ? 'Shams Charania' : 'Ian Rapoport',
      verified: true,
      created_at: new Date(now.getTime() - 4 * 60 * 60 * 1000).toISOString(),
      likes: 892,
      retweets: 234,
      sentiment: { score: -0.2, type: 'neutral', injury_signals: 1, positive_signals: 1, usage_signals: 0 },
      impact: -2.5,
      league,
      player
    }
  ];
}

function getMockBuzz(league: string): Beat[] {
  const now = new Date();
  const writers = league === 'NBA' 
    ? ['wojespn', 'ShamsCharania', 'ChrisBHaynes']
    : ['AdamSchefter', 'RapSheet', 'TomPelissero'];
  
  return writers.map((username, idx) => ({
    id: `buzz-${idx}`,
    text: `Breaking: Major roster news coming out of practice today. Multiple players upgraded to full participation.`,
    author_username: username,
    author_name: username.replace(/[0-9]/g, ''),
    verified: true,
    created_at: new Date(now.getTime() - (idx + 1) * 60 * 60 * 1000).toISOString(),
    likes: 500 - idx * 100,
    retweets: 150 - idx * 30,
    sentiment: { score: 0.5, type: 'positive', injury_signals: 0, positive_signals: 2, usage_signals: 1 },
    impact: 5.0,
    league,
    writer_rank: idx + 1
  }));
}
