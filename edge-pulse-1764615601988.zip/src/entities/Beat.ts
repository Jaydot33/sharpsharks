import type { EntityConfig } from "../hooks/useEntity";

export const beatEntityConfig: EntityConfig = {
  name: "Beat",
  orderBy: "created_at DESC",
  properties: {
    player: { type: "string", description: "Player name" },
    league: { type: "string", description: "Sport league" },
    content: { type: "string", description: "Tweet/news content" },
    author: { type: "string", description: "Reporter handle" },
    authorRank: { type: "number", description: "Reporter credibility score" },
    sentiment: { type: "number", description: "Sentiment score -1 to 1" },
    impact: {
      type: "string",
      enum: ["positive", "negative", "neutral"],
      description: "Projected impact on performance"
    },
    projectionAdjust: { type: "number", description: "Projection adjustment %" },
    sourceUrl: { type: "string", description: "Original tweet/article URL" },
    timestamp: { type: "string", description: "News timestamp ISO" }
  },
  required: ["player", "content", "author", "sentiment"]
};
