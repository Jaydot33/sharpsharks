import type { EntityConfig } from "../hooks/useEntity";

export const pickEntityConfig: EntityConfig = {
  name: "Pick",
  orderBy: "confidence DESC, created_at DESC",
  properties: {
    propId: { type: "integer", description: "Related prop ID" },
    player: { type: "string", description: "Player name" },
    league: { type: "string", description: "Sport league" },
    propType: { type: "string", description: "Prop type" },
    recommendation: {
      type: "string",
      enum: ["over", "under"],
      description: "Bet recommendation"
    },
    confidence: { type: "number", description: "Confidence score 0-100" },
    edge: { type: "number", description: "Edge percentage" },
    reasoning: { type: "string", description: "Pick rationale" },
    mlScore: { type: "number", description: "ML model score" },
    sentimentScore: { type: "number", description: "Social sentiment -1 to 1" },
    status: {
      type: "string",
      enum: ["pending", "won", "lost", "pushed"],
      default: "pending"
    }
  },
  required: ["player", "league", "propType", "recommendation", "confidence"]
};
