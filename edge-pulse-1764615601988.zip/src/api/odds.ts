import { BACKEND_URL } from './client';

export interface Prop {
  id?: number;
  league: string;
  player: string;
  prop_type: string;
  line: number;
  odds: number;
  projection: number;
  edge_pct: number;
  bookmaker: string;
  timestamp: string;
}

export interface PropsResponse {
  data: Prop[];
  timestamp: string;
  league: string;
}

/**
 * Fetch live player props from TheOddsAPI via backend
 */
export async function fetchLiveProps(league: string): Promise<Prop[]> {
  try {
    const response = await fetch(`${BACKEND_URL}/api/props/${league.toUpperCase()}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      console.error(`Failed to fetch props: ${response.statusText}`);
      return [];
    }

    const data: PropsResponse = await response.json();
    return data.data || [];
  } catch (error) {
    console.error('Error fetching props:', error);
    return [];
  }
}

/**
 * Fetch all supported leagues at once
 */
export async function fetchAllProps(): Promise<Record<string, Prop[]>> {
  const leagues = ['NBA', 'NFL', 'NCAAB', 'CFB'];
  const results: Record<string, Prop[]> = {};

  await Promise.all(
    leagues.map(async (league) => {
      results[league] = await fetchLiveProps(league);
    })
  );

  return results;
}

/**
 * Subscribe to real-time prop updates via WebSocket (future enhancement)
 */
export function subscribeToLiveProps(
  league: string,
  onUpdate: (props: Prop[]) => void
): () => void {
  const protocol = BACKEND_URL.startsWith('https') ? 'wss' : 'ws';
  const wsUrl = `${protocol}://${BACKEND_URL.replace('http://', '').replace('https://', '')}/ws/props/${league}`;

  let ws: WebSocket | null = null;

  try {
    ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log(`Connected to ${league} props stream`);
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        if (message.data && Array.isArray(message.data)) {
          onUpdate(message.data);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    ws.onclose = () => {
      console.log(`Disconnected from ${league} props stream`);
    };
  } catch (error) {
    console.error('Failed to create WebSocket:', error);
  }

  // Return unsubscribe function
  return () => {
    if (ws) {
      ws.close();
    }
  };
}
