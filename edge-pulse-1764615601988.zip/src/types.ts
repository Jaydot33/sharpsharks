export type League = "NBA" | "NFL" | "NCAAB" | "CFB";

export type PropType = "points" | "rebounds" | "assists" | "pass_yards" | "rush_yards" | "receptions";

export type Prop = {
  id: number;
  player: string;
  league: League;
  team: string;
  opponent: string;
  propType: PropType;
  line: number;
  overOdds: number;
  underOdds: number;
  projection: number;
  edge: number;
  source: string;
  gameTime: string;
  status: "active" | "locked" | "settled";
  created_at: string;
  updated_at: string;
};

export type Pick = {
  id: number;
  propId: number;
  player: string;
  league: string;
  propType: string;
  recommendation: "over" | "under";
  confidence: number;
  edge: number;
  reasoning: string;
  mlScore: number;
  sentimentScore: number;
  status: "pending" | "won" | "lost" | "pushed";
  created_at: string;
  updated_at: string;
};

export type Beat = {
  id: number;
  player: string;
  league: string;
  content: string;
  author: string;
  authorRank: number;
  sentiment: number;
  impact: "positive" | "negative" | "neutral";
  projectionAdjust: number;
  sourceUrl: string;
  timestamp: string;
  created_at: string;
  updated_at: string;
};
