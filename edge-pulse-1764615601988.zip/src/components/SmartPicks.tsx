import { TrendingUp, Brain, Target, Sparkles } from "lucide-react";
import { mockPicks } from "../lib/mock-data";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

export default function SmartPicks() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Brain className="w-8 h-8 text-teal-400" />
          <h2 className="text-2xl font-bold text-white">AI Smart Picks</h2>
        </div>
        <Badge className="bg-gradient-to-r from-teal-600 to-cyan-500 text-white">
          <Sparkles className="w-4 h-4 mr-1" />
          ML Powered
        </Badge>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {mockPicks.map((pick) => (
          <Card
            key={pick.id}
            className="bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700 hover:border-teal-500 transition-all duration-300 hover:shadow-xl hover:shadow-teal-500/20"
          >
            <CardHeader>
              <CardTitle className="flex items-start justify-between">
                <div>
                  <div className="text-white text-xl font-bold">{pick.player}</div>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline" className="border-teal-500 text-teal-400">
                      {pick.league}
                    </Badge>
                    <span className="text-gray-400 text-sm capitalize">
                      {pick.propType.replace("_", " ")}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="text-3xl font-bold text-teal-400">
                    {pick.confidence}
                  </div>
                  <div className="text-xs text-gray-400">confidence</div>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                <span className="text-gray-400">Recommendation</span>
                <Badge
                  className={
                    pick.recommendation === "over"
                      ? "bg-green-600 text-white"
                      : "bg-red-600 text-white"
                  }
                >
                  {pick.recommendation.toUpperCase()}
                </Badge>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-900 rounded-lg">
                <span className="text-gray-400">Edge</span>
                <span className="text-green-400 font-bold">
                  +{pick.edge.toFixed(1)}%
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Target className="w-4 h-4 text-teal-400" />
                  <span className="text-gray-400">ML Score:</span>
                  <span className="text-white font-medium">
                    {(pick.mlScore * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-teal-400" />
                  <span className="text-gray-400">Sentiment:</span>
                  <span className="text-white font-medium">
                    {pick.sentimentScore > 0 ? "+" : ""}
                    {pick.sentimentScore.toFixed(2)}
                  </span>
                </div>
              </div>

              <p className="text-gray-300 text-sm leading-relaxed border-t border-gray-700 pt-4">
                {pick.reasoning}
              </p>

              <Button className="w-full bg-teal-600 hover:bg-teal-700 text-white">
                Track This Pick
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
