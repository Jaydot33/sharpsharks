import os
import requests
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class TwitterService:
    """Service for fetching beat writer tweets and sentiment analysis"""
    
    def __init__(self):
        self.bearer_token = os.getenv("X_BEARER_TOKEN")
        self.base_url = os.getenv("TWITTER_API_BASE_URL", "https://api.twitter.com/2")
        
        # Top beat writers by sport
        self.beat_writers = {
            "NBA": [
                "wojespn",  # Adrian Wojnarowski
                "ShamsCharania",  # Shams Charania
                "ChrisBHaynes",  # Chris Haynes
                "TheSteinLine",  # Marc Stein
                "WindhorstESPN"  # Brian Windhorst
            ],
            "NFL": [
                "AdamSchefter",  # Adam Schefter
                "RapSheet",  # Ian Rapoport
                "JFowlerESPN",  # Jeremy Fowler
                "TomPelissero",  # Tom Pelissero
                "MikeGarafolo"  # Mike Garafolo
            ],
            "NCAAB": [
                "GoodmanHoops",  # Jeff Goodman
                "JonRothstein",  # Jon Rothstein
                "JeffBorzello",  # Jeff Borzello
                "TheAndyKatz"  # Andy Katz
            ],
            "CFB": [
                "PeteThamel",  # Pete Thamel
                "BruceFeldmanCFB",  # Bruce Feldman
                "Brett_McMurphy",  # Brett McMurphy
                "RossDellenger"  # Ross Dellenger
            ]
        }
        
        # Keywords for sentiment analysis
        self.injury_keywords = ["injury", "out", "questionable", "doubtful", "DNP", "ruled out", "miss", "sidelined"]
        self.positive_keywords = ["healthy", "cleared", "ready", "practicing", "full go", "starting", "active", "return"]
        self.usage_keywords = ["increased", "more touches", "expanded role", "minutes up", "featured", "primary"]
        self.negative_keywords = ["limited", "reduced", "fewer", "minutes down", "backup", "bench"]
    
    def get_headers(self) -> Dict[str, str]:
        """Get authorization headers for Twitter API"""
        return {
            "Authorization": f"Bearer {self.bearer_token}",
            "Content-Type": "application/json"
        }
    
    def search_tweets(self, query: str, max_results: int = 10) -> List[Dict]:
        """Search recent tweets matching query"""
        try:
            endpoint = f"{self.base_url}/tweets/search/recent"
            
            params = {
                "query": query,
                "max_results": max_results,
                "tweet.fields": "created_at,author_id,public_metrics,text",
                "expansions": "author_id",
                "user.fields": "username,name,verified"
            }
            
            response = requests.get(endpoint, headers=self.get_headers(), params=params, timeout=10)
            
            if response.status_code != 200:
                logger.error(f"Twitter API error: {response.status_code} - {response.text}")
                return []
            
            data = response.json()
            
            # Parse tweets
            tweets = []
            users = {user["id"]: user for user in data.get("includes", {}).get("users", [])}
            
            for tweet in data.get("data", []):
                author = users.get(tweet["author_id"], {})
                tweets.append({
                    "id": tweet["id"],
                    "text": tweet["text"],
                    "author_username": author.get("username", "unknown"),
                    "author_name": author.get("name", "Unknown"),
                    "verified": author.get("verified", False),
                    "created_at": tweet["created_at"],
                    "likes": tweet["public_metrics"]["like_count"],
                    "retweets": tweet["public_metrics"]["retweet_count"]
                })
            
            return tweets
            
        except Exception as e:
            logger.error(f"Error fetching tweets: {str(e)}")
            return []
    
    def get_player_beats(self, player_name: str, league: str = "NBA", hours: int = 24) -> List[Dict]:
        """Get recent beat writer tweets about a player"""
        
        # Get beat writers for league
        writers = self.beat_writers.get(league, self.beat_writers["NBA"])
        writer_handles = " OR from:".join(writers)
        
        # Build search query
        since_date = (datetime.utcnow() - timedelta(hours=hours)).strftime("%Y-%m-%d")
        query = f"{player_name} (from:{writer_handles}) -is:retweet"
        
        tweets = self.search_tweets(query, max_results=10)
        
        # Add sentiment analysis
        for tweet in tweets:
            tweet["sentiment"] = self.analyze_sentiment(tweet["text"])
            tweet["impact"] = self.calculate_impact(tweet)
            tweet["league"] = league
            tweet["player"] = player_name
        
        return tweets
    
    def analyze_sentiment(self, text: str) -> Dict[str, any]:
        """Analyze tweet sentiment for betting impact"""
        text_lower = text.lower()
        
        # Check for injury/availability
        injury_score = sum(1 for keyword in self.injury_keywords if keyword in text_lower)
        positive_score = sum(1 for keyword in self.positive_keywords if keyword in text_lower)
        
        # Check for usage changes
        usage_up = sum(1 for keyword in self.usage_keywords if keyword in text_lower)
        usage_down = sum(1 for keyword in self.negative_keywords if keyword in text_lower)
        
        # Calculate sentiment score (-1 to +1)
        total_signals = injury_score + positive_score + usage_up + usage_down
        if total_signals == 0:
            sentiment_score = 0.0
        else:
            sentiment_score = (positive_score + usage_up - injury_score - usage_down) / total_signals
        
        # Determine type
        sentiment_type = "neutral"
        if sentiment_score > 0.3:
            sentiment_type = "positive"
        elif sentiment_score < -0.3:
            sentiment_type = "negative"
        
        return {
            "score": round(sentiment_score, 2),
            "type": sentiment_type,
            "injury_signals": injury_score,
            "positive_signals": positive_score,
            "usage_signals": usage_up + usage_down
        }
    
    def calculate_impact(self, tweet: Dict) -> float:
        """Calculate projected impact on player props (-15% to +15%)"""
        sentiment = tweet.get("sentiment", {})
        score = sentiment.get("score", 0)
        
        # Base impact from sentiment
        base_impact = score * 10  # -10% to +10%
        
        # Boost for verified writers
        if tweet.get("verified", False):
            base_impact *= 1.5
        
        # Boost for engagement
        engagement = tweet.get("likes", 0) + tweet.get("retweets", 0) * 2
        engagement_boost = min(engagement / 1000, 0.5)  # Up to +0.5x
        
        final_impact = base_impact * (1 + engagement_boost)
        
        # Cap at -15% to +15%
        return max(-15, min(15, round(final_impact, 1)))
    
    def get_league_buzz(self, league: str = "NBA", hours: int = 6) -> List[Dict]:
        """Get general beat buzz for a league"""
        writers = self.beat_writers.get(league, self.beat_writers["NBA"])
        
        all_tweets = []
        for writer in writers[:3]:  # Top 3 writers to avoid rate limits
            query = f"from:{writer} -is:retweet"
            tweets = self.search_tweets(query, max_results=5)
            
            for tweet in tweets:
                tweet["sentiment"] = self.analyze_sentiment(tweet["text"])
                tweet["league"] = league
                tweet["writer_rank"] = writers.index(writer) + 1
            
            all_tweets.extend(tweets)
        
        # Sort by recency and engagement
        all_tweets.sort(key=lambda x: (
            datetime.fromisoformat(x["created_at"].replace("Z", "+00:00")).timestamp(),
            x.get("likes", 0) + x.get("retweets", 0) * 2
        ), reverse=True)
        
        return all_tweets[:15]  # Top 15 most relevant

# Singleton instance
twitter_service = TwitterService()
