import { useState, useCallback } from 'react';
import { apiClient } from '../api/client';

export function useProps(league: string, minEdge: number = 0) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await apiClient.getProps(league, minEdge);
      setData(result as any[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch props');
    } finally {
      setLoading(false);
    }
  }, [league, minEdge]);

  return { data, loading, error, fetch };
}

export function useBeats(player: string, league: string = 'NBA') {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await apiClient.getBeats(player, league);
      setData(result as any[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch beats');
    } finally {
      setLoading(false);
    }
  }, [player, league]);

  return { data, loading, error, fetch };
}

export function usePicks(league: string) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await apiClient.getPicks(league);
      setData(result as any[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch picks');
    } finally {
      setLoading(false);
    }
  }, [league]);

  return { data, loading, error, fetch };
}
