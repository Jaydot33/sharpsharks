from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List, Dict, Any

class PropResponse(BaseModel):
    id: Optional[int] = None
    league: str
    player: str
    prop_type: str
    line: float
    odds: int
    projection: float
    edge_pct: float
    bookmaker: str
    timestamp: str

class BeatResponse(BaseModel):
    id: Optional[int] = None
    league: str
    player: str
    text: str
    author: str
    sentiment: float
    impact: float
    created_at: str
    likes: int

class PickResponse(BaseModel):
    id: Optional[int] = None
    league: str
    player: str
    prop: str
    line: float
    pick: str
    confidence: float
    reasoning: str
    edge_pct: float
    components: Dict[str, float]
    created_at: Optional[str] = None

class UserResponse(BaseModel):
    id: Optional[int] = None
    email: str
    username: str
    tier: str = "free"
    created_at: Optional[str] = None

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

class LoginRequest(BaseModel):
    email: str
    password: str

class RegisterRequest(BaseModel):
    email: str
    username: str
    password: str

class EdgeAlertRequest(BaseModel):
    league: str
    player: Optional[str] = None
    prop_type: Optional[str] = None
    min_edge_pct: float = 5.0

class ParaySimulationRequest(BaseModel):
    picks: List[Dict[str, Any]]
    simulations: int = 10000
