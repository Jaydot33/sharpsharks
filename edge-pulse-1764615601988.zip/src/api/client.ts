import { jwtDecode } from 'jwt-decode';

export const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000';
const API_URL = BACKEND_URL;

interface TokenPayload {
  sub: string;
  exp: number;
}

export class ApiClient {
  private token: string | null = localStorage.getItem('token');

  setToken(token: string) {
    this.token = token;
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    return this.token;
  }

  isTokenValid(): boolean {
    if (!this.token) return false;
    try {
      const decoded = jwtDecode<TokenPayload>(this.token);
      return decoded.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${API_URL}${endpoint}`;
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      if (response.status === 401) {
        this.token = null;
        localStorage.removeItem('token');
        window.location.href = '/login';
      }
      throw new Error(`API Error: ${response.statusText}`);
    }

    return response.json();
  }

  // Auth endpoints
  async register(email: string, username: string, password: string) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, username, password }),
    });
  }

  async login(email: string, password: string) {
    return this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  }

  // Props endpoints
  async getProps(league: string, minEdge: number = 0) {
    return this.request(
      `/api/props/${league}?min_edge=${minEdge}`,
      { method: 'GET' }
    );
  }

  // Beats endpoints
  async getBeats(player: string, league: string = 'NBA') {
    return this.request(
      `/api/beats/${player}?league=${league}`,
      { method: 'GET' }
    );
  }

  // Picks endpoints
  async getPicks(league: string) {
    return this.request(`/api/picks/${league}`, { method: 'GET' });
  }

  // Alerts endpoints
  async createAlert(
    league: string,
    minEdgePct: number,
    player?: string,
    propType?: string
  ) {
    return this.request('/api/alerts', {
      method: 'POST',
      body: JSON.stringify({
        league,
        player,
        prop_type: propType,
        min_edge_pct: minEdgePct,
      }),
    });
  }

  // Parlay simulation
  async simulateParlay(picks: any[], simulations: number = 10000) {
    return this.request('/api/parlay-simulation', {
      method: 'POST',
      body: JSON.stringify({ picks, simulations }),
    });
  }

  // Health check
  async health() {
    return this.request('/health', { method: 'GET' });
  }

  // Cache status
  async getCacheStatus() {
    return this.request('/api/cache-status', { method: 'GET' });
  }
}

export const apiClient = new ApiClient();
