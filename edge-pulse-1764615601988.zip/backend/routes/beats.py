from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from services.twitter_service import twitter_service
from services.redis_service import redis_service
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/beats", tags=["beats"])

@router.get("/{player}")
async def get_player_beats(
    player: str,
    league: str = Query("NBA", regex="^(NBA|NFL|NCAAB|CFB)$"),
    hours: int = Query(24, ge=1, le=168)
):
    """Get beat writer tweets about a player with sentiment analysis"""
    
    # Check cache first
    cache_key = f"beats:{league}:{player}:{hours}"
    cached = redis_service.get(cache_key)
    if cached:
        return {"player": player, "league": league, "beats": cached, "cached": True}
    
    try:
        # Fetch from Twitter
        beats = twitter_service.get_player_beats(player, league, hours)
        
        # Cache for 10 minutes
        redis_service.set(cache_key, beats, ttl=600)
        
        return {
            "player": player,
            "league": league,
            "beats": beats,
            "count": len(beats),
            "cached": False
        }
        
    except Exception as e:
        logger.error(f"Error fetching beats for {player}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch beat writer data: {str(e)}")

@router.get("/league/{league}")
async def get_league_buzz(
    league: str,
    hours: int = Query(6, ge=1, le=48)
):
    """Get general beat buzz for a league"""
    
    if league not in ["NBA", "NFL", "NCAAB", "CFB"]:
        raise HTTPException(status_code=400, detail="Invalid league. Must be NBA, NFL, NCAAB, or CFB")
    
    # Check cache
    cache_key = f"buzz:{league}:{hours}"
    cached = redis_service.get(cache_key)
    if cached:
        return {"league": league, "buzz": cached, "cached": True}
    
    try:
        # Fetch from Twitter
        buzz = twitter_service.get_league_buzz(league, hours)
        
        # Cache for 10 minutes
        redis_service.set(cache_key, buzz, ttl=600)
        
        return {
            "league": league,
            "buzz": buzz,
            "count": len(buzz),
            "cached": False
        }
        
    except Exception as e:
        logger.error(f"Error fetching buzz for {league}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch beat buzz: {str(e)}")
