import { useState, useEffect } from 'react';
import { fetchLiveProps, Prop } from '../api/odds';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ArrowUpRight, ArrowDownLeft, Zap } from 'lucide-react';

export function LiveScanner() {
  const [props, setProps] = useState<Prop[]>([]);
  const [league, setLeague] = useState('NBA');
  const [loading, setLoading] = useState(false);
  const [sortBy, setSortBy] = useState<'edge' | 'line' | 'player'>('edge');
  const [filterEdge, setFilterEdge] = useState(5); // Show edges >= 5%

  useEffect(() => {
    loadProps();
    const interval = setInterval(loadProps, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, [league]);

  async function loadProps() {
    setLoading(true);
    const data = await fetchLiveProps(league);
    
    // Filter by minimum edge
    const filtered = data.filter((p) => p.edge_pct >= filterEdge);
    
    // Sort
    const sorted = [...filtered].sort((a, b) => {
      if (sortBy === 'edge') return b.edge_pct - a.edge_pct;
      if (sortBy === 'line') return b.line - a.line;
      return a.player.localeCompare(b.player);
    });
    
    setProps(sorted);
    setLoading(false);
  }

  const getEdgeColor = (edge: number) => {
    if (edge >= 10) return 'text-green-400';
    if (edge >= 7) return 'text-emerald-400';
    if (edge >= 5) return 'text-lime-400';
    return 'text-gray-400';
  };

  const getPropEmoji = (type: string) => {
    const map: Record<string, string> = {
      points: '🎯',
      rebounds: '🏀',
      assists: '🎪',
      pass_yards: '🏈',
      rush_yards: '🏃',
      other: '📊',
    };
    return map[type] || '📊';
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-2 flex-wrap">
          {['NBA', 'NFL', 'NCAAB', 'CFB'].map((l) => (
            <Button
              key={l}
              onClick={() => setLeague(l)}
              variant={league === l ? 'default' : 'outline'}
              size="sm"
              className={league === l ? 'bg-teal-600 hover:bg-teal-700' : ''}
            >
              {l}
            </Button>
          ))}
        </div>
        <Button
          onClick={loadProps}
          disabled={loading}
          size="sm"
          className="bg-teal-600 hover:bg-teal-700"
        >
          {loading ? '⚡ Syncing...' : '🔄 Refresh'}
        </Button>
      </div>

      {/* Filter & Sort */}
      <div className="flex gap-4 flex-wrap sm:justify-between sm:items-center">
        <div className="flex items-center gap-2">
          <label className="text-xs font-medium text-gray-400">Min Edge:</label>
          <input
            type="range"
            min="0"
            max="15"
            value={filterEdge}
            onChange={(e) => setFilterEdge(parseInt(e.target.value))}
            className="w-24 h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"
          />
          <span className="text-xs font-bold text-teal-400 w-12">{filterEdge}%</span>
        </div>
        <div className="flex gap-2">
          {['edge', 'line', 'player'].map((s) => (
            <Button
              key={s}
              onClick={() => setSortBy(s as 'edge' | 'line' | 'player')}
              variant={sortBy === s ? 'default' : 'outline'}
              size="sm"
              className={sortBy === s ? 'bg-teal-600' : 'text-gray-400'}
            >
              {s === 'edge' ? '⚡ Edge' : s === 'line' ? '📊 Line' : '👤 Player'}
            </Button>
          ))}
        </div>
      </div>

      {/* Props Grid */}
      {props.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          <p className="text-lg font-semibold">No props found with {filterEdge}%+ edge</p>
          <p className="text-sm mt-2">Lower the minimum edge filter to see more opportunities</p>
        </div>
      ) : (
        <div className="grid gap-3">
          {props.map((prop, idx) => (
            <Card
              key={`${prop.player}-${prop.prop_type}-${idx}`}
              className="bg-gradient-to-r from-gray-900 to-gray-800 border-gray-700 p-4 hover:border-teal-500 transition-all duration-200 hover:shadow-lg hover:shadow-teal-500/20"
            >
              <div className="flex items-center justify-between gap-4">
                {/* Left: Player & Prop */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-2xl">{getPropEmoji(prop.prop_type)}</span>
                    <div className="min-w-0">
                      <p className="font-bold text-white truncate">{prop.player}</p>
                      <p className="text-xs text-gray-400">
                        {prop.prop_type.replace('_', ' ').toUpperCase()}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Middle: Line & Projection */}
                <div className="flex-shrink-0 text-right">
                  <div className="flex items-center gap-1 mb-1">
                    <span className="text-sm font-semibold text-gray-300">{prop.line}</span>
                    {prop.projection > prop.line ? (
                      <ArrowUpRight className="w-4 h-4 text-green-400" />
                    ) : (
                      <ArrowDownLeft className="w-4 h-4 text-red-400" />
                    )}
                  </div>
                  <p className="text-xs text-gray-500">Proj: {prop.projection.toFixed(1)}</p>
                </div>

                {/* Right: Edge & Odds */}
                <div className="flex-shrink-0 text-right">
                  <div className={`font-bold text-lg flex items-center gap-1 justify-end mb-1 ${getEdgeColor(prop.edge_pct)}`}>
                    <Zap className="w-4 h-4" />
                    {prop.edge_pct.toFixed(1)}%
                  </div>
                  <Badge
                    variant="outline"
                    className={`text-xs ${prop.odds > 0 ? 'border-green-500 text-green-400' : 'border-red-500 text-red-400'}`}
                  >
                    {prop.odds > 0 ? '+' : ''}{prop.odds}
                  </Badge>
                </div>
              </div>

              {/* Bookmaker tag */}
              <div className="mt-2 flex items-center justify-between">
                <Badge variant="secondary" className="text-xs bg-gray-800 text-gray-300">
                  {prop.bookmaker}
                </Badge>
                <p className="text-xs text-gray-500">{new Date(prop.timestamp).toLocaleTimeString()}</p>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Stats Footer */}
      {props.length > 0 && (
        <div className="mt-6 grid grid-cols-3 gap-2 text-center p-4 bg-gray-900 rounded-lg border border-gray-800">
          <div>
            <p className="text-2xl font-bold text-teal-400">{props.length}</p>
            <p className="text-xs text-gray-500">Props Found</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-green-400">
              {(props.reduce((sum, p) => sum + p.edge_pct, 0) / props.length).toFixed(1)}%
            </p>
            <p className="text-xs text-gray-500">Avg Edge</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-blue-400">
              {props.filter((p) => p.projection > p.line).length}
            </p>
            <p className="text-xs text-gray-500">Overs</p>
          </div>
        </div>
      )}
    </div>
  );
}
