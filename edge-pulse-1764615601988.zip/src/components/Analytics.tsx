import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Activity, BarChart3, Calendar, Filter } from 'lucide-react';

type TimeRange = '7d' | '30d' | '90d' | 'season';
type League = 'NBA' | 'NFL' | 'NCAAB' | 'CFB';
type ChartType = 'trend' | 'performance' | 'movement' | 'comparison';

interface AnalyticsProps {}

// Sample historical data for player performance
const generatePlayerTrendData = (player: string, days: number) => {
  const data = [];
  const baseValue = player.includes('Jokic') ? 12 : player.includes('LeBron') ? 26 : 15;
  const today = new Date();
  
  for (let i = days; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const variance = Math.random() * 8 - 4;
    const actual = Math.max(0, baseValue + variance);
    const line = baseValue + (Math.random() * 2 - 1);
    
    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      actual: Number(actual.toFixed(1)),
      line: Number(line.toFixed(1)),
      projection: Number((baseValue + Math.random() * 2 - 1).toFixed(1)),
      edge: Number(((actual - line) / line * 100).toFixed(1))
    });
  }
  return data;
};

// Line movement data
const generateLineMovementData = () => {
  const data = [];
  const times = ['9:00 AM', '12:00 PM', '3:00 PM', '6:00 PM', '9:00 PM', '11:00 PM'];
  let currentLine = 25.5;
  
  times.forEach((time) => {
    const movement = Math.random() * 1.5 - 0.5;
    currentLine += movement;
    data.push({
      time,
      line: Number(currentLine.toFixed(1)),
      volume: Math.floor(Math.random() * 5000) + 1000,
      movement: movement > 0 ? 'up' : movement < 0 ? 'down' : 'stable'
    });
  });
  return data;
};

// Hit rate comparison data
const generateHitRateData = () => {
  return [
    { prop: 'Points Over', hitRate: 58, games: 45, profit: 12.5 },
    { prop: 'Points Under', hitRate: 52, games: 38, profit: 3.2 },
    { prop: 'Rebounds Over', hitRate: 65, games: 52, profit: 18.7 },
    { prop: 'Rebounds Under', hitRate: 48, games: 41, profit: -2.1 },
    { prop: 'Assists Over', hitRate: 61, games: 48, profit: 14.3 },
    { prop: 'Assists Under', hitRate: 54, games: 35, profit: 5.8 }
  ];
};

// Performance distribution data
const generateDistributionData = (player: string) => {
  const data = [];
  const baseValue = player.includes('Jokic') ? 12 : 26;
  
  for (let i = 0; i < 50; i++) {
    const value = Math.round(baseValue + (Math.random() * 12 - 6));
    data.push({
      game: i + 1,
      value,
      result: value > baseValue ? 'over' : 'under'
    });
  }
  return data;
};

export default function Analytics({}: AnalyticsProps) {
  const [timeRange, setTimeRange] = useState<TimeRange>('30d');
  const [selectedLeague, setSelectedLeague] = useState<League>('NBA');
  const [selectedPlayer, setSelectedPlayer] = useState('Nikola Jokic');
  const [chartType, setChartType] = useState<ChartType>('trend');

  const players = {
    NBA: ['Nikola Jokic', 'LeBron James', 'Luka Doncic', 'Jayson Tatum'],
    NFL: ['Patrick Mahomes', 'Josh Allen', 'Christian McCaffrey'],
    NCAAB: ['Zach Edey', 'Armando Bacot', 'Hunter Dickinson'],
    CFB: ['Caleb Williams', 'Bo Nix', 'Michael Penix Jr']
  };

  const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : timeRange === '90d' ? 90 : 180;
  const trendData = generatePlayerTrendData(selectedPlayer, days);
  const lineMovementData = generateLineMovementData();
  const hitRateData = generateHitRateData();
  const distributionData = generateDistributionData(selectedPlayer);

  const stats = {
    avgActual: (trendData.reduce((sum, d) => sum + d.actual, 0) / trendData.length).toFixed(1),
    avgLine: (trendData.reduce((sum, d) => sum + d.line, 0) / trendData.length).toFixed(1),
    hitRate: ((trendData.filter(d => d.actual > d.line).length / trendData.length) * 100).toFixed(0),
    avgEdge: (trendData.reduce((sum, d) => sum + d.edge, 0) / trendData.length).toFixed(1)
  };

  return (
    <div className="min-h-screen bg-[#1a1a1a] text-white pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#2a2a2a] to-[#1a1a1a] border-b border-gray-800 px-4 py-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#00d4ff] rounded-lg flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-black" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Analytics</h1>
              <p className="text-gray-400 text-sm">Advanced prop performance insights</p>
            </div>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* League Filter */}
            <div>
              <label className="block text-xs text-gray-400 mb-1">League</label>
              <select
                value={selectedLeague}
                onChange={(e) => {
                  setSelectedLeague(e.target.value as League);
                  setSelectedPlayer(players[e.target.value as League][0]);
                }}
                className="w-full bg-[#2a2a2a] border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#00d4ff] transition-colors"
              >
                <option value="NBA">NBA</option>
                <option value="NFL">NFL</option>
                <option value="NCAAB">NCAAB</option>
                <option value="CFB">CFB</option>
              </select>
            </div>

            {/* Player Filter */}
            <div>
              <label className="block text-xs text-gray-400 mb-1">Player</label>
              <select
                value={selectedPlayer}
                onChange={(e) => setSelectedPlayer(e.target.value)}
                className="w-full bg-[#2a2a2a] border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#00d4ff] transition-colors"
              >
                {players[selectedLeague].map((player) => (
                  <option key={player} value={player}>{player}</option>
                ))}
              </select>
            </div>

            {/* Time Range */}
            <div>
              <label className="block text-xs text-gray-400 mb-1">Time Range</label>
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value as TimeRange)}
                className="w-full bg-[#2a2a2a] border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#00d4ff] transition-colors"
              >
                <option value="7d">Last 7 Days</option>
                <option value="30d">Last 30 Days</option>
                <option value="90d">Last 90 Days</option>
                <option value="season">Full Season</option>
              </select>
            </div>

            {/* Chart Type */}
            <div>
              <label className="block text-xs text-gray-400 mb-1">View</label>
              <select
                value={chartType}
                onChange={(e) => setChartType(e.target.value as ChartType)}
                className="w-full bg-[#2a2a2a] border border-gray-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#00d4ff] transition-colors"
              >
                <option value="trend">Performance Trend</option>
                <option value="movement">Line Movement</option>
                <option value="performance">Hit Rate Analysis</option>
                <option value="comparison">Distribution</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Key Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-[#2a2a2a] rounded-xl p-4 border border-gray-800">
            <div className="text-xs text-gray-400 mb-1">Avg Actual</div>
            <div className="text-2xl font-bold text-[#00d4ff]">{stats.avgActual}</div>
            <div className="text-xs text-gray-500 mt-1">vs {stats.avgLine} line</div>
          </div>
          <div className="bg-[#2a2a2a] rounded-xl p-4 border border-gray-800">
            <div className="text-xs text-gray-400 mb-1">Over Hit Rate</div>
            <div className="text-2xl font-bold text-green-400">{stats.hitRate}%</div>
            <div className="text-xs text-gray-500 mt-1">{trendData.length} games</div>
          </div>
          <div className="bg-[#2a2a2a] rounded-xl p-4 border border-gray-800">
            <div className="text-xs text-gray-400 mb-1">Avg Edge</div>
            <div className={`text-2xl font-bold ${Number(stats.avgEdge) > 0 ? 'text-green-400' : 'text-red-400'}`}>
              {Number(stats.avgEdge) > 0 ? '+' : ''}{stats.avgEdge}%
            </div>
            <div className="text-xs text-gray-500 mt-1">Expected value</div>
          </div>
          <div className="bg-[#2a2a2a] rounded-xl p-4 border border-gray-800">
            <div className="text-xs text-gray-400 mb-1">Trend</div>
            <div className="flex items-center gap-2">
              {Number(stats.avgEdge) > 0 ? (
                <>
                  <TrendingUp className="w-6 h-6 text-green-400" />
                  <span className="text-2xl font-bold text-green-400">Strong</span>
                </>
              ) : (
                <>
                  <TrendingDown className="w-6 h-6 text-red-400" />
                  <span className="text-2xl font-bold text-red-400">Weak</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Main Chart */}
        {chartType === 'trend' && (
          <div className="bg-[#2a2a2a] rounded-xl p-6 border border-gray-800">
            <div className="mb-6">
              <h3 className="text-lg font-bold mb-1">{selectedPlayer} - Performance Trend</h3>
              <p className="text-sm text-gray-400">Actual vs Line vs Projection over time</p>
            </div>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis 
                  dataKey="date" 
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                />
                <YAxis 
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1a1a1a', 
                    border: '1px solid #333',
                    borderRadius: '8px',
                    padding: '12px'
                  }}
                  labelStyle={{ color: '#fff', marginBottom: '8px' }}
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '20px' }}
                  iconType="line"
                />
                <Line 
                  type="monotone" 
                  dataKey="actual" 
                  stroke="#00d4ff" 
                  strokeWidth={3}
                  name="Actual Performance"
                  dot={{ fill: '#00d4ff', r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="line" 
                  stroke="#ff6b6b" 
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  name="Betting Line"
                  dot={{ fill: '#ff6b6b', r: 3 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="projection" 
                  stroke="#ffd93d" 
                  strokeWidth={2}
                  name="AI Projection"
                  dot={{ fill: '#ffd93d', r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {chartType === 'movement' && (
          <div className="bg-[#2a2a2a] rounded-xl p-6 border border-gray-800">
            <div className="mb-6">
              <h3 className="text-lg font-bold mb-1">Line Movement Today</h3>
              <p className="text-sm text-gray-400">Real-time odds movement and betting volume</p>
            </div>
            <ResponsiveContainer width="100%" height={400}>
              <AreaChart data={lineMovementData}>
                <defs>
                  <linearGradient id="lineGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00d4ff" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis 
                  dataKey="time" 
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                />
                <YAxis 
                  yAxisId="left"
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                  label={{ value: 'Line', angle: -90, position: 'insideLeft', fill: '#999' }}
                />
                <YAxis 
                  yAxisId="right"
                  orientation="right"
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                  label={{ value: 'Volume', angle: 90, position: 'insideRight', fill: '#999' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1a1a1a', 
                    border: '1px solid #333',
                    borderRadius: '8px',
                    padding: '12px'
                  }}
                />
                <Legend wrapperStyle={{ paddingTop: '20px' }} />
                <Area 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="line" 
                  stroke="#00d4ff" 
                  strokeWidth={3}
                  fill="url(#lineGradient)"
                  name="Betting Line"
                />
                <Bar 
                  yAxisId="right"
                  dataKey="volume" 
                  fill="#4a5568" 
                  opacity={0.3}
                  name="Bet Volume"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}

        {chartType === 'performance' && (
          <div className="bg-[#2a2a2a] rounded-xl p-6 border border-gray-800">
            <div className="mb-6">
              <h3 className="text-lg font-bold mb-1">Hit Rate by Prop Type</h3>
              <p className="text-sm text-gray-400">Success rate and profitability analysis</p>
            </div>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={hitRateData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis 
                  type="number"
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                  label={{ value: 'Hit Rate (%)', position: 'insideBottom', offset: -5, fill: '#999' }}
                />
                <YAxis 
                  dataKey="prop" 
                  type="category"
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                  width={120}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1a1a1a', 
                    border: '1px solid #333',
                    borderRadius: '8px',
                    padding: '12px'
                  }}
                  formatter={(value: any, name: string) => {
                    if (name === 'hitRate') return [`${value}%`, 'Hit Rate'];
                    if (name === 'games') return [value, 'Games'];
                    if (name === 'profit') return [`${value > 0 ? '+' : ''}${value}%`, 'ROI'];
                    return [value, name];
                  }}
                />
                <Legend wrapperStyle={{ paddingTop: '20px' }} />
                <Bar dataKey="hitRate" name="Hit Rate %">
                  {hitRateData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.hitRate >= 55 ? '#10b981' : entry.hitRate >= 50 ? '#fbbf24' : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded"></div>
                <span className="text-gray-400">Strong (55%+)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-yellow-500 rounded"></div>
                <span className="text-gray-400">Average (50-55%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded"></div>
                <span className="text-gray-400">Weak (&lt;50%)</span>
              </div>
            </div>
          </div>
        )}

        {chartType === 'comparison' && (
          <div className="bg-[#2a2a2a] rounded-xl p-6 border border-gray-800">
            <div className="mb-6">
              <h3 className="text-lg font-bold mb-1">Performance Distribution</h3>
              <p className="text-sm text-gray-400">Game-by-game results vs betting line</p>
            </div>
            <ResponsiveContainer width="100%" height={400}>
              <ScatterChart>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis 
                  dataKey="game" 
                  name="Game #"
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                  label={{ value: 'Game Number', position: 'insideBottom', offset: -5, fill: '#999' }}
                />
                <YAxis 
                  dataKey="value"
                  name="Performance"
                  stroke="#666"
                  tick={{ fill: '#999', fontSize: 12 }}
                  label={{ value: 'Stat Value', angle: -90, position: 'insideLeft', fill: '#999' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1a1a1a', 
                    border: '1px solid #333',
                    borderRadius: '8px',
                    padding: '12px'
                  }}
                  cursor={{ strokeDasharray: '3 3' }}
                  formatter={(value: any, name: string) => {
                    if (name === 'Performance') return [value, 'Value'];
                    return [value, name];
                  }}
                />
                <Scatter name="Performance" data={distributionData} fill="#00d4ff">
                  {distributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.result === 'over' ? '#10b981' : '#ef4444'} />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
            <div className="mt-4 flex items-center justify-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-gray-400">Over ({distributionData.filter(d => d.result === 'over').length} games)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span className="text-gray-400">Under ({distributionData.filter(d => d.result === 'under').length} games)</span>
              </div>
            </div>
          </div>
        )}

        {/* Additional Insights */}
        <div className="grid sm:grid-cols-2 gap-6">
          {/* Recent Form */}
          <div className="bg-[#2a2a2a] rounded-xl p-6 border border-gray-800">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="w-5 h-5 text-[#00d4ff]" />
              <h3 className="font-bold">Recent Form (L10)</h3>
            </div>
            <div className="space-y-3">
              {trendData.slice(-10).reverse().map((game, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                      game.actual > game.line ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                    }`}>
                      {game.actual > game.line ? 'W' : 'L'}
                    </div>
                    <div>
                      <div className="text-sm font-medium">{game.date}</div>
                      <div className="text-xs text-gray-400">Line: {game.line}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold">{game.actual}</div>
                    <div className={`text-xs ${game.edge > 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {game.edge > 0 ? '+' : ''}{game.edge}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Key Metrics */}
          <div className="bg-[#2a2a2a] rounded-xl p-6 border border-gray-800">
            <div className="flex items-center gap-2 mb-4">
              <Filter className="w-5 h-5 text-[#00d4ff]" />
              <h3 className="font-bold">Key Insights</h3>
            </div>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-400">Consistency Score</span>
                  <span className="text-sm font-bold">78/100</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-[#00d4ff] h-2 rounded-full transition-all duration-300" style={{ width: '78%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-400">Over Tendency</span>
                  <span className="text-sm font-bold text-green-400">{stats.hitRate}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full transition-all duration-300" style={{ width: `${stats.hitRate}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-400">Line Value</span>
                  <span className="text-sm font-bold text-yellow-400">Strong</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div className="bg-yellow-500 h-2 rounded-full transition-all duration-300" style={{ width: '65%' }}></div>
                </div>
              </div>
              <div className="pt-4 border-t border-gray-700">
                <div className="text-xs text-gray-400 mb-2">Sharp Recommendation</div>
                <div className="text-sm text-white leading-relaxed">
                  <span className="text-[#00d4ff] font-bold">{selectedPlayer}</span> shows strong over tendency 
                  with {stats.hitRate}% hit rate. Current line of {stats.avgLine} offers value when 
                  actual average is {stats.avgActual}. Consider over on favorable matchups.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
