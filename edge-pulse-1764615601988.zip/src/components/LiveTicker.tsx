import { TrendingUp } from "lucide-react";
import { mockProps } from "../lib/mock-data";

export default function LiveTicker() {
  const topProps = mockProps.slice(0, 3);

  return (
    <div className="bg-gradient-to-r from-teal-600 to-cyan-500 py-3 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-8 animate-pulse">
          <div className="flex items-center gap-2 text-white font-semibold whitespace-nowrap">
            <TrendingUp className="w-5 h-5" />
            <span>LIVE EDGES</span>
          </div>
          <div className="flex gap-8 overflow-x-auto scrollbar-hide">
            {topProps.map((prop) => (
              <div key={prop.id} className="flex items-center gap-3 text-white whitespace-nowrap">
                <span className="font-medium">{prop.player}</span>
                <span className="text-teal-100">
                  {prop.propType.toUpperCase()} O/U {prop.line}
                </span>
                <span className="bg-white text-teal-600 px-2 py-1 rounded font-bold text-sm">
                  +{prop.edge.toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
