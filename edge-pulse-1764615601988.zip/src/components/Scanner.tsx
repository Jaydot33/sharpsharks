import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';

interface Prop {
  league: string;
  player: string;
  prop_type: string;
  line: number;
  odds: number;
  projection: number;
  edge_pct: number;
  bookmaker: string;
  timestamp: string;
  team?: string;
  opponent?: string;
}

export function Scanner() {
  const [activeLeague, setActiveLeague] = useState('NBA');
  const [props, setProps] = useState<Record<string, Prop[]>>({
    NBA: [],
    NFL: [],
    NCAAB: [],
    CFB: []
  });
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'edge' | 'player' | 'line'>('edge');

  useEffect(() => {
    fetchAllProps();
    // Refresh every 5 minutes
    const interval = setInterval(fetchAllProps, 300000);
    return () => clearInterval(interval);
  }, []);

  const fetchAllProps = async () => {
    setLoading(true);
    try {
      const leagues = ['NBA', 'NFL', 'NCAAB', 'CFB'];
      const results: Record<string, Prop[]> = {};

      for (const league of leagues) {
        try {
          const response = await fetch(`/api/props/${league}`);
          if (response.ok) {
            const data = await response.json();
            results[league] = data.data || [];
          }
        } catch (error) {
          console.error(`Error fetching ${league}:`, error);
          results[league] = [];
        }
      }

      setProps(results);
    } catch (error) {
      console.error('Error fetching props:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSortedProps = (leagueProps: Prop[]) => {
    const sorted = [...leagueProps];
    if (sortBy === 'edge') {
      return sorted.sort((a, b) => (b.edge_pct || 0) - (a.edge_pct || 0));
    } else if (sortBy === 'player') {
      return sorted.sort((a, b) => a.player.localeCompare(b.player));
    } else {
      return sorted.sort((a, b) => (a.line || 0) - (b.line || 0));
    }
  };

  const getEdgeColor = (edge: number) => {
    if (edge > 10) return 'bg-green-600';
    if (edge > 5) return 'bg-green-500';
    if (edge > 0) return 'bg-green-400';
    return 'bg-gray-600';
  };

  const leagueProps = getSortedProps(props[activeLeague] || []);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Edge Scanner</h2>
        <div className="flex gap-2">
          <button
            onClick={fetchAllProps}
            disabled={loading}
            className="px-3 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors text-sm disabled:opacity-50"
          >
            {loading ? 'Refreshing...' : 'Refresh'}
          </button>
        </div>
      </div>

      <Tabs value={activeLeague} onValueChange={setActiveLeague} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800">
          <TabsTrigger value="NBA" className="data-[state=active]:bg-teal-600">NBA</TabsTrigger>
          <TabsTrigger value="NFL" className="data-[state=active]:bg-teal-600">NFL</TabsTrigger>
          <TabsTrigger value="NCAAB" className="data-[state=active]:bg-teal-600">NCAAB</TabsTrigger>
          <TabsTrigger value="CFB" className="data-[state=active]:bg-teal-600">CFB</TabsTrigger>
        </TabsList>

        {['NBA', 'NFL', 'NCAAB', 'CFB'].map((league) => (
          <TabsContent key={league} value={league} className="space-y-4">
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setSortBy('edge')}
                className={`px-3 py-1 rounded text-sm transition-colors ${
                  sortBy === 'edge'
                    ? 'bg-teal-600 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                Sort by Edge
              </button>
              <button
                onClick={() => setSortBy('player')}
                className={`px-3 py-1 rounded text-sm transition-colors ${
                  sortBy === 'player'
                    ? 'bg-teal-600 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                Sort by Player/Team
              </button>
              <button
                onClick={() => setSortBy('line')}
                className={`px-3 py-1 rounded text-sm transition-colors ${
                  sortBy === 'line'
                    ? 'bg-teal-600 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                Sort by Line
              </button>
            </div>

            {loading && leagueProps.length === 0 ? (
              <Card className="bg-gray-800 border-gray-700 p-8 text-center">
                <p className="text-gray-400">Loading {league} props...</p>
              </Card>
            ) : leagueProps.length === 0 ? (
              <Card className="bg-gray-800 border-gray-700 p-8 text-center">
                <p className="text-gray-400">No games scheduled for today</p>
              </Card>
            ) : (
              <div className="space-y-2">
                {leagueProps.map((prop, idx) => (
                  <Card
                    key={idx}
                    className="bg-gray-800 border-gray-700 p-4 hover:bg-gray-750 transition-colors cursor-pointer"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-6 gap-4 items-center">
                      <div className="md:col-span-2">
                        <p className="font-semibold text-white">{prop.player}</p>
                        <p className="text-sm text-gray-400">{prop.prop_type}</p>
                        {prop.team && (
                          <p className="text-xs text-gray-500">
                            {prop.team} vs {prop.opponent}
                          </p>
                        )}
                      </div>

                      <div>
                        <p className="text-sm text-gray-400">Line</p>
                        <p className="font-semibold text-white">{prop.line?.toFixed(1) || '-'}</p>
                      </div>

                      <div>
                        <p className="text-sm text-gray-400">Projection</p>
                        <p className="font-semibold text-teal-400">
                          {prop.projection?.toFixed(1) || '-'}
                        </p>
                      </div>

                      <div>
                        <p className="text-sm text-gray-400">Odds</p>
                        <p className="font-semibold text-white">{prop.odds?.toFixed(2) || '-'}</p>
                      </div>

                      <div className="flex items-end justify-between md:justify-end gap-2">
                        <div>
                          <p className="text-sm text-gray-400">Edge</p>
                          <Badge
                            className={`${getEdgeColor(prop.edge_pct || 0)} text-white font-bold`}
                          >
                            {(prop.edge_pct || 0).toFixed(1)}%
                          </Badge>
                        </div>
                        <div className="text-xs text-gray-500">{prop.bookmaker}</div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
