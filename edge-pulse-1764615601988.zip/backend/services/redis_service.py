import os
import json
import redis
from typing import Optional, Any
import logging

logger = logging.getLogger(__name__)

class RedisService:
    """Redis caching service for props, beats, and picks"""
    
    def __init__(self):
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
        
        try:
            # Parse Redis URL
            if redis_url.startswith("rediss://"):
                # SSL connection
                self.client = redis.from_url(
                    redis_url,
                    decode_responses=True,
                    ssl_cert_reqs=None
                )
            else:
                self.client = redis.from_url(redis_url, decode_responses=True)
            
            # Test connection
            self.client.ping()
            logger.info("Redis connection established")
            
        except Exception as e:
            logger.warning(f"Redis connection failed: {str(e)}. Using in-memory cache fallback.")
            self.client = None
            self._memory_cache = {}
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        try:
            if self.client:
                value = self.client.get(key)
                if value:
                    return json.loads(value)
            else:
                return self._memory_cache.get(key)
        except Exception as e:
            logger.error(f"Redis GET error: {str(e)}")
        return None
    
    def set(self, key: str, value: Any, ttl: int = 300) -> bool:
        """Set value in cache with TTL (seconds)"""
        try:
            if self.client:
                return self.client.setex(key, ttl, json.dumps(value))
            else:
                self._memory_cache[key] = value
                return True
        except Exception as e:
            logger.error(f"Redis SET error: {str(e)}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete key from cache"""
        try:
            if self.client:
                return bool(self.client.delete(key))
            else:
                return self._memory_cache.pop(key, None) is not None
        except Exception as e:
            logger.error(f"Redis DELETE error: {str(e)}")
            return False
    
    def clear_pattern(self, pattern: str) -> int:
        """Clear all keys matching pattern"""
        try:
            if self.client:
                keys = self.client.keys(pattern)
                if keys:
                    return self.client.delete(*keys)
            else:
                count = 0
                for key in list(self._memory_cache.keys()):
                    if pattern.replace("*", "") in key:
                        del self._memory_cache[key]
                        count += 1
                return count
        except Exception as e:
            logger.error(f"Redis CLEAR error: {str(e)}")
        return 0

# Singleton instance
redis_service = RedisService()
