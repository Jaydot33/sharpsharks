import type { EntityConfig } from "../hooks/useEntity";

export const propEntityConfig: EntityConfig = {
  name: "Prop",
  orderBy: "created_at DESC",
  properties: {
    player: { type: "string", description: "Player name" },
    league: { 
      type: "string", 
      enum: ["NBA", "NFL", "NCAAB", "CFB"],
      description: "Sport league" 
    },
    team: { type: "string", description: "Player team" },
    opponent: { type: "string", description: "Opponent team" },
    propType: { 
      type: "string",
      enum: ["points", "rebounds", "assists", "pass_yards", "rush_yards", "receptions"],
      description: "Prop bet type" 
    },
    line: { type: "number", description: "Betting line" },
    overOdds: { type: "number", description: "Over odds" },
    underOdds: { type: "number", description: "Under odds" },
    projection: { type: "number", description: "Statistical projection" },
    edge: { type: "number", description: "Calculated edge percentage" },
    source: { type: "string", description: "Data source API" },
    gameTime: { type: "string", description: "Game start time ISO format" },
    status: { 
      type: "string",
      enum: ["active", "locked", "settled"],
      default: "active",
      description: "Prop status"
    }
  },
  required: ["player", "league", "propType", "line", "edge"]
};
