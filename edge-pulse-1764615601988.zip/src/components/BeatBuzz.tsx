import { TrendingUp, TrendingDown, Minus, ExternalLink } from "lucide-react";
import { mockBeats } from "../lib/mock-data";
import { Badge } from "./ui/badge";
import { Card, CardContent } from "./ui/card";

export default function BeatBuzz() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Beat Buzz</h2>
        <Badge variant="outline" className="border-teal-500 text-teal-400">
          Live Updates
        </Badge>
      </div>

      <div className="space-y-4">
        {mockBeats.map((beat) => {
          const ImpactIcon =
            beat.impact === "positive"
              ? TrendingUp
              : beat.impact === "negative"
              ? TrendingDown
              : Minus;

          const impactColor =
            beat.impact === "positive"
              ? "text-green-400"
              : beat.impact === "negative"
              ? "text-red-400"
              : "text-gray-400";

          const sentimentWidth = Math.abs(beat.sentiment) * 100;
          const sentimentColor =
            beat.sentiment > 0 ? "bg-green-500" : "bg-red-500";

          return (
            <Card
              key={beat.id}
              className="bg-gray-800 border-gray-700 hover:border-teal-500 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 space-y-3">
                    <div className="flex items-center gap-3">
                      <ImpactIcon className={`w-5 h-5 ${impactColor}`} />
                      <div>
                        <span className="text-white font-semibold">
                          {beat.player}
                        </span>
                        <span className="text-gray-400 mx-2">•</span>
                        <Badge variant="outline" className="border-gray-600 text-gray-300">
                          {beat.league}
                        </Badge>
                      </div>
                    </div>

                    <p className="text-gray-300 leading-relaxed">{beat.content}</p>

                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-teal-400 font-medium">
                          {beat.author}
                        </span>
                        <Badge className="bg-teal-600 text-white">
                          Rank {beat.authorRank}
                        </Badge>
                      </div>
                      <span className="text-gray-500">
                        {new Date(beat.timestamp).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                      <a
                        href={beat.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-teal-400 hover:text-teal-300 transition-colors"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>Sentiment Score</span>
                        <span className={beat.sentiment > 0 ? "text-green-400" : "text-red-400"}>
                          {beat.sentiment > 0 ? "+" : ""}
                          {beat.sentiment.toFixed(2)}
                        </span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div
                          className={`${sentimentColor} h-2 rounded-full transition-all duration-300`}
                          style={{ width: `${sentimentWidth}%` }}
                        />
                      </div>
                    </div>

                    {beat.projectionAdjust !== 0 && (
                      <div className="inline-flex items-center gap-2 bg-gray-900 px-3 py-1.5 rounded-lg">
                        <span className="text-gray-400 text-sm">
                          Projection Adjustment:
                        </span>
                        <span className={`font-semibold ${impactColor}`}>
                          {beat.projectionAdjust > 0 ? "+" : ""}
                          {beat.projectionAdjust}%
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
