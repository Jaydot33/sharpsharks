import redis
import json
from datetime import timedelta
from typing import Optional, Any
from config import settings

class CacheManager:
    def __init__(self):
        try:
            self.redis_client = redis.from_url(settings.redis_url, decode_responses=True)
            self.redis_client.ping()
        except Exception as e:
            print(f"Redis connection failed: {e}. Using in-memory cache.")
            self.redis_client = None
            self.memory_cache = {}
    
    async def get(self, key: str) -> Optional[Any]:
        try:
            if self.redis_client:
                value = self.redis_client.get(key)
                return json.loads(value) if value else None
            else:
                return self.memory_cache.get(key)
        except Exception as e:
            print(f"Cache get error: {e}")
            return None
    
    async def set(self, key: str, value: Any, ttl_minutes: int = 5):
        try:
            json_value = json.dumps(value)
            if self.redis_client:
                self.redis_client.setex(
                    key,
                    timedelta(minutes=ttl_minutes),
                    json_value
                )
            else:
                self.memory_cache[key] = value
        except Exception as e:
            print(f"Cache set error: {e}")
    
    async def delete(self, key: str):
        try:
            if self.redis_client:
                self.redis_client.delete(key)
            else:
                self.memory_cache.pop(key, None)
        except Exception as e:
            print(f"Cache delete error: {e}")
    
    async def clear(self):
        try:
            if self.redis_client:
                self.redis_client.flushdb()
            else:
                self.memory_cache.clear()
        except Exception as e:
            print(f"Cache clear error: {e}")

cache_manager = CacheManager()
