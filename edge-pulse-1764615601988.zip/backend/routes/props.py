from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from datetime import datetime
from services.odds_api import odds_api_service
from services.redis_service import redis_service
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/props", tags=["props"])

@router.get("/{league}")
async def get_props(
    league: str,
    date: str = Query(None, description="Date in YYYY-MM-DD format (default: today)")
):
    """Get player props with edges for a league"""
    
    if league not in ["NBA", "NFL", "NCAAB", "CFB"]:
        raise HTTPException(status_code=400, detail="Invalid league. Must be NBA, NFL, NCAAB, or CFB")
    
    # Check cache first
    cache_key = f"props:{league}:{date or 'today'}"
    cached = redis_service.get(cache_key)
    if cached:
        return {
            "data": cached,
            "league": league,
            "count": len(cached),
            "cached": True,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    try:
        # Fetch from TheOddsAPI
        props = odds_api_service.get_league_props(league, date)
        
        # Cache for 5 minutes
        redis_service.set(cache_key, props, ttl=300)
        
        return {
            "data": props,
            "league": league,
            "count": len(props),
            "cached": False,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error fetching props for {league}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch props: {str(e)}")

@router.get("/player/{player_name}")
async def get_player_props(
    player_name: str,
    league: str = Query("NBA", regex="^(NBA|NFL|NCAAB|CFB)$")
):
    """Get all props for a specific player"""
    
    # Check cache
    cache_key = f"player_props:{league}:{player_name}"
    cached = redis_service.get(cache_key)
    if cached:
        return {"player": player_name, "props": cached, "cached": True}
    
    try:
        # Fetch all league props and filter by player
        all_props = odds_api_service.get_league_props(league)
        player_props = [p for p in all_props if p.get("player", "").lower() == player_name.lower()]
        
        # Cache for 5 minutes
        redis_service.set(cache_key, player_props, ttl=300)
        
        return {
            "player": player_name,
            "league": league,
            "props": player_props,
            "count": len(player_props),
            "cached": False
        }
        
    except Exception as e:
        logger.error(f"Error fetching props for {player_name}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch player props: {str(e)}")
